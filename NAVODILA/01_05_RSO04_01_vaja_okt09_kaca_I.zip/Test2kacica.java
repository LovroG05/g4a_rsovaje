import java.util.LinkedList;
import java.util.Queue;       // interface na LinkedList

/**
 * Write a description of class Test2 here.
 *
 *
 *    uporabimo Queue interface na LinkedList-u, in uporabimo zgolj metode iz
 *    Queue (add - doda na konec vrste, remove, odstrani z začetka vrste)
 *    
 *    - ideja : glava kače je dejansko rep vrste(queue)
 *              premaknemo tako, da iz glave vrste(rep kače) odstranimo el. in
 *              kačo premaknemo tako, da v glavo dodamo nov element v smeri gibanja
 *              (glej konstruktor !)
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Test2kacica{
   
    Queue kaca = new LinkedList<El>();
    Smer smer = null;
    El glavaKace = null;

    /**
     *   naredi 'koliko' dolgo kačo, na naključni začetni poziciji z naključno začetno
     *   smerjo gibanja
     */
    public Test2kacica(int koliko){
        
        smer = new Smer(); for (int i=0;i<(int)(Math.random()*5);i++) smer.ccw();
        
        var barva    = javafx.scene.paint.Color.GREEN; 
        var randomPozicija = new Element( (int)(Math.random()*(800-4*koliko))+2*koliko ,
                                          (int)(Math.random()*(600-4*koliko))+2*koliko  );
        glavaKace = new El(barva,randomPozicija);
        
        kaca.add(glavaKace); 
        while (--koliko>0){
            var temp = new El ( barva,
                                new Element(glavaKace.koordinata.x()+smer.getX(),
                                            glavaKace.koordinata.y()+smer.getY() )
                               )  ;
            kaca.add(temp);
            glavaKace=temp;
        }
        
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public static void main(String[] args){
        
        var k1 = new Test2kacica(5);
        System.out.println(k1.kaca);
        
        /* var k2 = new Test2kacica(15);
        var k3 = new Test2kacica(7); */
       
    }
}
