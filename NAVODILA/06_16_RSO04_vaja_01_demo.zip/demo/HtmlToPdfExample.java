import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.FileSystems;
import org.jsoup.Jsoup;
import org.jsoup.helper.W3CDom;
import org.jsoup.nodes.Document;
import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;

import com.openhtmltopdf.util.*;

/**
 *   Convert HTML to PDF in Java + Openhtmltopdf and PDFBox
 */
public class HtmlToPdfExample {
  public static void main(String[] args) {
     
    //--- tole je za logger : privzeto je loggin level INFO kar je zoprno celo tedaj, ko je vse ok, spodaj imate 2 varianti,
    //     prvo popolnoima brez logiranja, drugo za nivo WARNING (ta kaže tudi vse prezrte definicije v css )
    //XRLog.listRegisteredLoggers().forEach(logger -> XRLog.setLevel(logger, java.util.logging.Level.OFF));
    //XRLog.listRegisteredLoggers().forEach(logger -> XRLog.setLevel(logger, java.util.logging.Level.WARNING)); 

    try {
      // HTML file - Input
      File inputHTML = new File(HtmlToPdfExample.class.getClassLoader().getResource("files/test.html").getFile());

      // Converted PDF file - Output
      String outputPdf = "./Test.pdf";
      
      HtmlToPdfExample htmlToPdf = new HtmlToPdfExample();
      
      //create well formed HTML
      org.w3c.dom.Document doc = htmlToPdf.createWellFormedHtml(inputHTML);
      System.out.println("Starting conversion to PDF...");
      htmlToPdf.xhtmlToPdf(doc, outputPdf);
    } catch (IOException e) {
        System.out.println("Error while converting HTML to PDF " + e.getMessage());
        e.printStackTrace();
    }
  }
  
  // Creating well formed document
  //
  /*
   *   če se rabi manipulacija z samim dokumentom; 
   *   Document je .... DOM
   *   to, da ga npr. nekdo hoče narediti, ima
   *   tule: https://examples.javacodegeeks.com/java-development/core-java/xml/dom/create-dom-document-from-scratch/
   *   primerček, kako naredi nov dokement oz. tudi, ga spremeni
   */
  //
  private org.w3c.dom.Document createWellFormedHtml(File inputHTML) throws IOException {

    /*  VARIANTA 1 : beremo html iz datoteke */
    Document document = Jsoup.parse(inputHTML, "UTF-8");   //
    /*
     * String html = "<html><head><title>First parse</title></head><body><p>Parsed HTML into a doc.</p></body></html>";
     * Document doc = Jsoup.parse(html);
     * 
     * več na: https://www.javadoc.io/doc/org.jsoup/jsoup/1.12.1/org/jsoup/Jsoup.html
     */
    String s_css="@font-face{font-family:Doulos;src:url(\"./files/fonts/DoulosSIL-Regular.ttf\"); body{font-family:arial, roman ,Doulos !important;}";
        
    /* VARIANTA 2: html ustvarimo on-the-fly */
    String html = "<html><head><meta charset=\"UTF-8\" /><title>First parse</title><style>body{font-family:CharisSIL,arial, roman, sans serif;}</style></head><body> <p>Parsed HTML into a doc.</p>ŠĐČĆŽ<br>šđčćž</body></html>";
    document = Jsoup.parse(html);
    
    document.outputSettings().syntax(Document.OutputSettings.Syntax.xml);
    System.out.println("HTML parsing done...");
    return new W3CDom().fromJsoup(document);
  }
  
  private void xhtmlToPdf(org.w3c.dom.Document doc, String outputPdf) throws IOException {
    // base URI to resolve future resources 
    String baseUri = FileSystems.getDefault()
                //.getPath("F:/", "Anshu/NetJs/Programs/", "src/main/resources/template")
                .getPath("./files")
                .toUri()
                .toString();
    OutputStream os = new FileOutputStream(outputPdf);
    PdfRendererBuilder builder = new PdfRendererBuilder();
    builder.withUri(outputPdf);
    builder.toStream(os);
    // add external font; naš je dodan preko CSS (glej definicijo za selector body !!
    builder.useFont(new File(getClass().getClassLoader().getResource("files/fonts/CharisSIL-Regular.ttf").getFile()), "CharisSIL");
    builder.withW3cDocument(doc, baseUri);
    builder.run();
    System.out.println("PDF creation completed"); 
    os.close();
  }
}


/*
  od Java 11 naprej je možno celotno datoteko prebrati v string (od java 8 kot sekvenco bytov):
    Path filePath = Path.of("c:/temp/demo.txt");
    String content = Files.readString(fileName);

    glej cel delujoč primer v navodilih vaje
 */